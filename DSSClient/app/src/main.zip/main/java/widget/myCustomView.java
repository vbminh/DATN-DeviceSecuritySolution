package widget;

import android.content.Context;
import android.widget.RelativeLayout;

public class myCustomView extends RelativeLayout {
    public myCustomView(Context context) {
        super(context);
    }
}
