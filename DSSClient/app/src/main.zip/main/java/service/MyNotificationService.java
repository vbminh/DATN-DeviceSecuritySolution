package service;

import android.service.notification.NotificationListenerService;

public class MyNotificationService extends NotificationListenerService {
}
